package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin(origins = "http://localhost:4200")
public class ReservationController {

    private final ReservationRepository reservationRepository;
    private final VehiculeRepository vehiculeRepository;

    public ReservationController(ReservationRepository reservationRepository,
                                 VehiculeRepository vehiculeRepository) {
        this.reservationRepository = reservationRepository;
        this.vehiculeRepository = vehiculeRepository;
    }

    @PostMapping
    public ResponseEntity<?> creer(@RequestBody Reservation reservation) {
        if (reservation.getDateDebut() == null || reservation.getDateFin() == null
                || !reservation.getDateFin().isAfter(reservation.getDateDebut())) {
            return ResponseEntity.badRequest().body("Dates invalides");
        }
        if (reservation.getVehiculeId() == null) {
            return ResponseEntity.badRequest().body("Véhicule manquant");
        }
        Vehicule v = vehiculeRepository.findById(reservation.getVehiculeId()).orElse(null);
        if (v == null) {
            return ResponseEntity.badRequest().body("Véhicule introuvable");
        }

        long jours = ChronoUnit.DAYS.between(reservation.getDateDebut(), reservation.getDateFin());
        double prixJour = v.getPrixParJour() * (1 - v.getReduction() / 100.0);

        reservation.setId(null);
        reservation.setAgenceId(v.getAgenceId());
        reservation.setPrixTotal(jours * prixJour);
        reservation.setStatut("EN_ATTENTE");
        return ResponseEntity.ok(reservationRepository.save(reservation));
    }

    @GetMapping("/client/{clientId}")
    public List<Reservation> parClient(@PathVariable Long clientId) {
        return reservationRepository.findByClientId(clientId);
    }

    @GetMapping("/agence/{agenceId}")
    public List<Reservation> parAgence(@PathVariable Long agenceId) {
        return reservationRepository.findByAgenceId(agenceId);
    }

    @PutMapping("/{id}/statut")
    public ResponseEntity<?> changerStatut(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String statut = body.get("statut");
        if (!"ACCEPTEE".equals(statut) && !"REFUSEE".equals(statut)) {
            return ResponseEntity.badRequest().body("Statut invalide");
        }
        return reservationRepository.findById(id)
                .map(r -> {
                    r.setStatut(statut);
                    return ResponseEntity.ok(reservationRepository.save(r));
                })
                .orElse(ResponseEntity.notFound().build());
    }
}